DROP TABLE IF EXISTS `#__jsn_uniform_payment_paypal_logs`;
