<?php
/**
 * Install File
 * Does the stuff for the specific extensions
 *
 * @package         Advanced Module Manager
 * @version         4.22.9
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2015 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

class extensionsInstaller extends NoNumberInstallerInstaller
{
	var $name = 'Advanced Module Manager';
	var $alias = 'advancedmodules';

	public function install(&$states, &$ext)
	{
		$ext = $this->name . ' (admin component, frontend component & system plugin)';

		// COMPONENT
		$states[] = $this->installExtension($states, $this->alias, 'NoNumber ' . $this->name, 'component', array('link' => '', 'admin_menu_link' => ''));

		// SYSTEM PLUGIN
		$states[] = $this->installExtension($states, $this->alias, 'System - NoNumber ' . $this->name, 'plugin', array('folder' => 'system'));
	}

	// Stuff to do before installation / update
	public function beforeInstall()
	{
		$this->fixFileVersions();
	}

	// Stuff to do after installation / update
	public function afterInstall()
	{
		// main table
		$query = "CREATE TABLE IF NOT EXISTS `#__advancedmodules` (
			`moduleid` INT(11) UNSIGNED NOT NULL DEFAULT '0',
			`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
			`params` TEXT NOT NULL,
			PRIMARY KEY (`moduleid`)
		) DEFAULT CHARSET=utf8;";
		$this->db->setQuery($query);
		$this->db->execute();

		// add asset_id column
		$query = "SHOW COLUMNS FROM `" . $this->db->getPrefix() . "advancedmodules` LIKE 'asset_id'";
		$this->db->setQuery($query);
		$hasasset = $this->db->loadResult();
		if (!$hasasset)
		{
			$query = "ALTER TABLE `#__advancedmodules` ADD `asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `moduleid`";
			$this->db->setQuery($query);
			$this->db->execute();
		}

		$query = $this->db->getQuery(true);

		// hide admin menu
		$query->clear()
			->delete('#__menu')
			->where($this->db->quoteName('path') . ' = ' . $this->db->quote('advancedmodules'))
			->where($this->db->quoteName('type') . ' = ' . $this->db->quote('component'))
			->where($this->db->quoteName('client_id') . ' = 1');
		$this->db->setQuery($query);
		$this->db->execute();

		// remove frontend component from extensions table
		$query->clear()
			->delete('#__extensions')
			->where($this->db->quoteName('element') . ' = ' . $this->db->quote('com_advancedmodules'))
			->where($this->db->quoteName('type') . ' = ' . $this->db->quote('component'))
			->where($this->db->quoteName('client_id') . ' = 0');
		$this->db->setQuery($query);
		$this->db->execute();

		// remove initial menu assignment settings
		$query->clear()
			->update('#__advancedmodules as a')
			->set('a.params = ' . $this->db->quote(''))
			->where('a.params = ' . $this->db->quote('{"assignto_menuitems":0,"assignto_menuitems_selection":[]}'));
		$this->db->setQuery($query);
		$this->db->execute();

		// correct old keys and values
		$query->clear()
			->select('a.moduleid,a. params')
			->from('#__advancedmodules as a');
		$this->db->setQuery($query);
		$rows = $this->db->loadObjectList();
		foreach ($rows as $row)
		{
			if (empty($row->params))
			{
				continue;
			}

			if ($row->params['0'] != '{')
			{
				$row->params = str_replace('assignto_secscats', 'assignto_cats', $row->params);
				$row->params = str_replace('flexicontent', 'fc', $row->params);

				$params = JRegistryFormat::getInstance('INI')->stringToObject($row->params);
			}
			else
			{
				$params = json_decode($row->params);
			}

			// move tooltip to notes field
			if (isset($params->tooltip) && !empty($params->tooltip))
			{
				$query->clear()
					->update('#__modules as m')
					->set('m.note = ' . $this->db->quote($params->tooltip))
					->where('m.id = ' . (int) $row->moduleid);
				$this->db->setQuery($query);
				$this->db->execute();
				unset($params->tooltip);
			}

			// concatenate sef and non-sef url fields
			if (isset($params->assignto_urls_selection_sef))
			{
				$params->assignto_urls_selection = trim($params->assignto_urls_selection . "\n" . $params->assignto_urls_selection_sef);
				unset($params->assignto_urls_selection_sef);
				unset($params->show_url_field);
			}

			// set urls_regex value if assignto_urls is used
			if (!empty($params->assignto_urls) && !isset($params->assignto_urls_regex))
			{
				$params->assignto_urls_regex = 1;
			}

			foreach ($params as $k => &$v)
			{
				switch ($k)
				{
					case 'assignto_php_selection':
					case 'assignto_urls_selection':
					case 'assignto_ips_selection':
						$v = str_replace(array('\n', '\|'), array("\n", '|'), $v);
						break;
					case 'color':
						$v = str_replace('#', '', $v);
						$v = (empty($v) || $v == 'none') ? 'none' : $v;
						if ($v && $v != 'none')
						{
							$v = '#' . strtolower($v);
						}
						break;
					case 'assignto_users_selection':
						$v = implode(',', explode('|', $v));
						break;
					default:
						if (
							(substr($k, -10) == '_selection' || substr($k, -4) == '_inc')
							&& !is_array($v)
						)
						{
							// convert | separated strings to arrays
							$v = explode('|', $v);
						}
						break;
				}
			}

			if (!empty($params->assignto_cats_selection))
			{
				foreach ($params->assignto_cats_selection as $key => $val)
				{
					if (strpos($val, ':') !== false)
					{
						$params->assignto_cats_selection[$key] = substr($val, strpos($val, ':') + 1);
					}
				}
			}

			$params = json_encode($params);

			if ($params == $row->params)
			{
				continue;
			}

			$query->clear()
				->update('#__advancedmodules as a')
				->set('a.params = ' . $this->db->quote($params))
				->where('a.moduleid = ' . (int) $row->moduleid);
			$this->db->setQuery($query);
			$this->db->execute();
		}

		$this->deleteOldFiles();
	}

	// Fix wrong version numbers
	private function fixFileVersions()
	{
		$this->fixFileVersionsByFile(array(
			JPATH_ADMINISTRATOR . '/components/com_advancedmodules/advancedmodules.xml',
			JPATH_PLUGINS . '/system/advancedmodules/advancedmodules.xml'
		));
	}

	// Fix wrong version numbers
	private function deleteOldFiles()
	{
		if (JV == 'j2')
		{
			return;
		}

		nnFile::delete(array(
			JPATH_SITE . '/components/com_advancedmodules/advancedmodules.xml',
			JPATH_SITE . '/components/com_advancedmodules/script.advancedmodules.php',
			JPATH_SITE . '/plugins/system/advancedmodules/modulehelper.php'
		));
	}
}
